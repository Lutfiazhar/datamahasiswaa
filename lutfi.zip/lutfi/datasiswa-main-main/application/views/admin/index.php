<div class="container">
    <h1>Welcome To Our University</h1>
</div>
<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://simaba.upnjatim.ac.id/umum/maba2023-0.jpg" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://www.upnjatim.ac.id/wp-content/uploads/2021/08/kampus-upn-surabay.jpg" class="d-block w-100" alt="10px">
    </div>
    <div class="carousel-item">
      <img src="https://blog.static.mamikos.com/wp-content/uploads/2020/02/upn-veteran-jatim.jpg" class="d-block w-100" alt="...">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>